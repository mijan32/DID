declare const validResponseTypes: string[];
declare const validDisplays: string[];
declare const validPrompt: string[];
declare const defaultThemes: {
    outline: string;
    filledOrange: string;
    filledBlack: string;
    custom: string;
};
declare const defaultShapes: {
    sharpEdges: string;
    softEdges: string;
    roundedEdges: string;
};
declare const buttonTypes: {
    standard: string;
    icon: string;
};
declare const defaultButtonLabel = "Sign in with e-Signet";
export { validResponseTypes, validDisplays, validPrompt, defaultThemes, defaultShapes, buttonTypes, defaultButtonLabel, };
