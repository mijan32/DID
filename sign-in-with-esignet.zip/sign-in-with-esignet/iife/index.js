/******************************************************************************
Mon Aug 07 2023 06:19:21 GMT+0000 (Coordinated Universal Time)
sign-in-with-esignet v0.9.0
A vanilla javascript component for rendering “Sign in with..” button on mosip client’s web page for oidc integration.
Copyright 2023
MPL-2.0 license 
******************************************************************************/
var SignInWithEsignetButton = (function (exports) {
    'use strict';

    /******************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    var img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAR8AAAE0CAYAAAAVPDe4AABWd0lEQVR4Xu29aWwjaXrn+Y+DwZuiSOpWSkopD+V91Jl19u12X+5uu321sR7PYAcwBhjAWMwu9tt8mv2yGMx6MbsDLHbX9gwwa7tt97SrD1d1dXdV15lVlVV5X5IyUykplRIlUbwZ536ICIqKpMQ3Dl7S+wMyGXwieAUZfz3v8zzv8zITExMaKBQKpcWwVgOFQqG0Aio+FAqlLVDxoVAobYGKD4VCaQtUfCgUSlug4kOhUNoCFR8KhdIWqPhQKJS2QMWHQqG0BSo+FAqlLVDxoVAobYGKD4VCaQtUfCgUSltg6Kx2CilyLI7KyATknh7IiRQ0BtAAcLlN8NkM/MtL8C8vWR9GodSFig+lIWowjMLppyEm+wAN0BiAgVYVH/1WgwaALRcR//RjCGtp69NQKNug4kPZFXF0AsVjZ6HyPDQGDcVHYwBAQ+jeLHquXbE+HYVShcZ8KDtSPHYWxVPPQON91l0NKUxOYeVzX4ASCll3USgAFR9KPTSfD/nzL6Iyfti6yxZSrAern/s8ykND1l0UCh12UbajROMonH4WSjQOQANjDq2MYRbpsMvcx0D/eQUeP0L80iWwkmR9Sco+hYoPpUpl5CBK02eh+cxhlnfiAwZgJQmJix9CSNNgNIWKDwWAxgsoHjuHyvCELhZMdY+n4mM+Z3huDtFbt6gXtM+h4rPPkaO9KJx6Dkq0BzDFosniAwBcqYTeS5eoF7SPoeKzjymPH0Xh6DkwhmCgheJj2oKPHqHn0qfUC9qHUPHZh6jBMPInn4PU2w8AbRUfBhpYSUbs2lUEHzzc2kfZ81Dx2WeUx46iOHUKmo+v2totPgDAMBqE9BpiV66D39zcOoayZ6His09Qg2HkT1yA1NunG5itr71TxMc8LHLrDkIzc2DoUGxPQ8VnH1Aam0Zp8pSRQjfFwJ34sLKI8I3LKB2YgJhMeSo+YABGkhC9cp0OxfYwVHz2MHK0F/kTFyBH4tWL2gvx4XKbiFz5CHw2AwAoHDmO/JFpT8XHPM6fXkP45h34Vte2HkfZE1Dx2YNovIDi5CmUxo5WbdaL2qn4CMtLiFz96IkhkRzrwebZpyH29HgqPub7CT5YQOjGHXDF0tbjKV0NFZ89RunANIqTp7cPsepc1E7EJ3TrMgL37lYfZ0Xz+ZA7egyFg1Oeiw8DAJKM0MwcQnfvPyF+lO6Dis8eQeodQP7YBSjBsG6oFZo6F7Ud8WFKRUQuvQvOGGY1QkymsHH+KcjBkKfio8F435KM8N17CN/YWQgpnQ8Vny5HjvSicORpSHG9Zqd6kXskPsLKEkJXL9r2NFTTC5qc1A0eio++RwNbKiFyfQbB+wvmM1K6CCo+XYoaiKB48DQqg5PVIC/gnfgwsoTgzDX477vzLsRUChvnztf09fFOfPTPDbDFIiLXZxC6v6gbKF0BFZ8uQw1EUJw4jfLgpCEaWxkmwBvx4fIZRC69C7ZUqB7jltz0NHJHp5siPmaanyuVEL1GRahboOLTJaiBCEoTp1EenDIuN1M0vBWf0Ow1BGauV/d5idTTg+ypU6gkk7rBY/GBUezIlUqIXZtF6B4VoU6Gik+HY4pOZWAKqBEar8WHy20gcvVDcDmyoLIbimNjyJ48CVXwNUV8TDtf1D2h4OIKWFHWjZSOgYpPhyLHB1EaPw25Z8C4qHS8Fh9GlhCcv43gzLXqsa1A9fmQm55Gceog0CTxMY9hJBnROw8Qvf2AilAHQcWnw6gMHII4egxKuNe8pJomPr6NFUSufehpbMcu+lDsJKS+BFDnfXohPrWPC99bQvzqHPgCLVZsN1R8OgA1EIHYfwjl0eNQOR9Ywwtolviw5QLCty9BWOmcFHVp/ADy00ehhoJNFR/z0YHVDcRuzSO0sGoeTGkxVHzaiJQcQ6X/EKTkmH5pGRdKM8UnNHcVgQe3wchidV8nUTh2FIVDk9B8HNBE8THPD18sI3ZrHpG5R3RI1mKo+LQY1R+BOHAYYv8UFH9kSyyaLD7CxgoiN95v6xCLFM3nQ+7MCZTGRpsuPrXnKTL3CJG5ZQQeb5hPQGkiVHxagMYLkBLjkBNjEJNjprV6wZj3myE+XLmAyPUP4Nt4bOzoHpRQCIXjh1EeH22J+JjwxRJiNxcQWlgFny9v20fxDio+TURKjBv/xqDxAhjrhYHmiQ9XKSA0dwX+pTnjke5RwgkokQTUYBhyMAwlFAbDqGBYDQyjQmE1yIwKGPc5WQS/uQmmVASfyULYyFmfkgipL4nC8SMQU4mWiI+ZCQQ0hBbSCD3U/9FhmbdQ8fEYKTEOuVcXHY3zbV0IRkFds8WHUSQEH95CcP6WJ3GdSvIIpMQ41PggVIGHxqgApwsNWA0Mq4JhVbCsCplVIbEqNFYDyypgGRUaq0LiVCisCkapILSwgtDCKkLz9vvz6CJ0GJW+RMvEx7zPSjJCD9cQml9F6KH99055Eio+LtE4AVJiAnJsEFLvOMALtXtbJj6MLOqi89AD0eH8qKROozRwEqqPBzgNHKtB41RX4qOxCsCoAKuAL5YQv/wAkbv2s01iXxKF44dQ6dfT860QH/0WgKaBlWWE5tOGGFEhcgoVHweo/ijE+Djk2BDE3nGwtZ5H9Yev25otPowsIbBw0xvRAaCFRiCOfgGVQAQKp4tHM8QHrH4beJxB6u058Dn7713sSyB/4jAqfb0tFZ/ax7KSogvRPBUiu1DxIUDjBEjRYUi945Biw1CF2p45aIv4QJYQWryJgEeiAwCITUMe/iJkToPIaS0RH7AKWEnE4Gt3IKw5K/wT+xLIH5lAeaS/5eJjPS40v47A8iZC82vg8xXzAEodqPjUwRQbOToMKToIJZjc+qHV/ljbID5MpYDQ/csQ0g+9Ex0ATPQYMPgFSBx2FR+oFXClNLjNZYABWLkCPr9Rc6FrkOI90AQe8HGQeqMoJSOQ/OyO4gNGASuLGPzHGQhp59klJRxE9sQhFA4OG5bWi88WGvhCBaH5NQQeZRGaX6/ZRwEVHx1ViEIJJnXvJjIEOaTPumaNiwmoEYk2iQ+/+RjC8iz8y7PmAzyDEfrADn8Hqs9XV3xYJYfg42vwrd8HW8lbH06E2BtFfnIQ+UMDUP3ME+IDVgFfqGD4b++CrSjWh9tCCQdRODiC/JExKALfNvHZ/lvREFjOIvAoW73d7+w78dE4P9RgEnJkGEowBSWYhCJEqqJQ67Z3gvgIj2fhfzwLPtO8Oh1u4LeB8BBUTtsmPirKCC6+C//aHetDHKMKPDJnxpE9MfiE+IBVEbmzjtSb3rTCUH08SqP92Dx5CHLE33bxsdoDyzkI60UElrIQ1ovgc/trmLanxUcNpKAJUaiBFOTIsO7hCNGqCOgXv/EX0fghdYL48GIewvIM/Is3PR1a1YP1j4Id/C40Tt0mPhIqCM39EFypOUHU/KF+pF+ZfEJ8wKoY/c93wGfttW1tRKW/F9npcRRGUrphm4C0R3y2P14DnxchrBcgrJUQWMqBz1ccBeK7he4XH84PzZ+C5osChtCovhjUYBJa1dXWxcW87VTx8a0/hPB4BsLavGlsOr7kN6FFDj4hPr65vwFXSlsP95T84T6kX514Qnwit9eR+vkj6+GeIIeDyE8OITs9BtXHdZT4bD9Ot7OSAmGtCGGtBD5XgbBWgpAugRXdDU07gc4XH18M4KMA5wf8KYAB1OCIfhsahlYdohi/jRqR6QbxYcU8Aos34FufB1t2Fk9xCsP6IQz/qR7bqREfLXcLvsU3rYc3hZUvH0ZxIrpNfFhZwuhfzICtqNbDPSU/OYTigT4URw1vyKSDxGfbc1iOCTzKgxWVqhgJaT1bGFjq/Pl7aJX4MHwM4GMWWxQMH9u6GFlBFxcAjOnNGAKxXSwA1bjVoAsMjK+FQXeID6OI8K09gH/pBrhC+7IgXGAKfOqbT4gPN/tXYCRnUyHsIkf9WPj9E9vEB6yC/p8sIDTbGjGWwwHkp4aQnxyCHA50jfhs3655PuMxrKhWyxfYimJkErceG1isEama3y2flTwf9tajaeLD+kfBho+DDU4BrKBfhObFbHxQBlviYYoAqsdtCcZeEB9GFSGsPQC/8QC+Fg6rdoOPXAAXf26b+MhyGty9v7Ye2lSWvnsMYp+wTXxiV9aReGvFemjTEXsjyB47gOKBlD4sg/4b0W/RVeKztV1zf9txdWzGNisqCM3mEbmxicCCs/qrRnDxePzfWo2uYP3wJb4GvuclsL4+gDW/QOsFbNxYbCTHaZb7JtbjavfV2p84rva2ZnubkBAet21bEeFbu4fAwqcIzfwavvV5cKXNrQPaDB+5AMYXg2YUDGosoOXvgim0VhyVkA/l4bB+MRj/GFVF5Ebr09FcWUToYRo91+chbOTBqCrERETfaf0N1P4WGt2vt209vp7Net9qq7ddz1ZLo+MYQOMYiH1+5E/EIPYFEHxQAKPUCqN7PBUfxtcHof+PdNGxfkDmyQ/NWPcTHtfJ4sOJefg2HsC/+ClCs7+Gb/1BRwlOLXz4PMCHtokPNq+DqTQ30PwkDPJHe7eJj9zDI/5hczJtpPiyRYQephG7tQhftgQwDKSY2WnR8ltodL/etvX4ejbrfaut3nY9Wy2NjrNsSwkBuTNxBO8XwRW9C3R7Jj4MF4PQ9wcAI+gXo/UD1rEx1v2Ex3Wa+PCldfhXbiH44EMEHn4E30bnCk4tvtgXARbbPZ/MlZbFe0xYUcHmuf5t4gNGQ+TmZtODziQwigphI4/w/RXErzzQPSJFhRwNQuPYmgNrH1X/t7Jt23p8PZv1vtVWb7uerZZGx9XZ1jgGhekIwrfznn0nnomPL/EtMLzRBJyp8wHr2BjrfsLj2i0+rJiHsPEAgcfXEZl7C/7la+Czj8BKzRkbNws+cuFJ8cndarn4MIqGzNODT4hPaC4PPtt5PXR8myWEHq6h5+pDBB5vgpUUaDwLJejbfmC930/tdq3NxGqz3rfa6m3Xs9XS6LgdtjWOQXk0iOhVb4bDnogPFzwBLnyu+kb3mvgwigghuwD/6k2EFj5CaOEjCJkH4ItrYDTv3NBWU098kH4HaMNnKh7sgRLmLZ5PtiPFpxY+X0FwcQPR28uIzKxAWC8AYKAEBWj8Dl5Rvd+cidVmvW+11duuZ6ul0XE7bQNQwjz4nAxh1X01tifZLn/qjwAjzqNB2yY+1WyUYeuGbBcj5eHLLcFXWgOfXwJXbG/soVkEBv8MGm/M4TKyXdrd/2g9rC5S7wAADUqsF/Dx+rlmAJXRoEGDL7sJVhLh28yCkRqnbZe/NYXySKhmzpeKxK8fI3ap84evOyEmwigPxVAcS6A8FDWs5u/fkmHSf4268FapObZ6nOWY6nbN89U+ZttrGLfV4+rYrK9pfT8A+JyM0f/7fo3dGa7Fh+Fi8Pf/C/1tdaH4MGoFbGkNfGEJXDENrrQGVmztsKMdMFwM/r5/QSQ+Gi9A7hmEmBqFHO2FFIsDLMAwKsBoYFm91YbKapBYTW+7YdgZRgNfLoDd3IRvdQ2BxZW6a2bVE5/4xTTi77evDsprdDGKojwUQ3koCtVvZIKrv9I6F3sHig8YYPi/PHTt/bgWHy54Ar74V/S31eHiA0UEW0mDzy+CLa+BLaX3hdDUgxVGISS+t6v4SIlxiP2HISVH9aGZITD6MI1cfBhWhcJoUFgVKquC38wiMre0bbma/SA+VuSoH2IiBDEZQnkoAjEZguqvGapZhaCeINQTkBaIT+KtVddeqWvx4SMXwEef199Wh4gPVBEop8FUVsGIOTDlNNjyGhjFnVLvJXYTn0rqCEqj58EEwlXR8VJ8VMacRiEidnMBsZuLWPnq+L4Tn3rIUQFiUhckMRk07geMvXUEoZ6AtEB84h+su/5uulZ8GDENTRGByioYtaKLjSKCKXrTjmGvU098JEFDjlmGEk4ArNFArIniA0b/x8oyWDkHOVnb52d/is9ObAlREHJMgBz1QY7qtzqtFZ/QbB79P1qu2Wcf1+Ij9H4LbGDKM/HRyotbjxXT0NQKoFQA0Sh8K6cBlXowbrGKTzEko+hXoLAaGCP71SrxAaPpgsPJgL8EsDIVHxuYIqT6OYipIABATPn1mBIDiKkgVMFUF2/EJ7BQxODfLtXss4978Ul8D6x/lFx85CyUtTeqj9fKnbNe+H4jMPhnUH0a8hERZZ8GldV7M7dNfFhVb6/hLwO8SMWnSYipgBHs3rr0118dgJjyE4uPsFrB8H95WLPPPrXRrZagyVlo5YXqP0r70DgNhbCoN4PvGBhAFACFh7BCPdxmIKTLCCwWEFgsVv/ZbV0r9tUuEeUM1+LDsH6ridIN+FMohUWoVXe7wxAFVPrN2hhKs3GbNneCe/Hh+6wmSqfD+sEMfw3atvkjncfmmX4UD27vA0VpDnY9HwCWsgD7uHu0AzTJ/gqVFG9hB7+md4fsAtJfGIWYMlPNlE5C7HM36mm5+NBMVXthe58DExyxmjsWVeCQ/mL3vN9uJbBYtJqajivxofGe7oLhY2Djz1rNHY+YCiDzHB3e7zXciQ+N93QVbM/zVpNrvjQ0iD//xlfxwz/5Pn70z/4If/07v43/4fQ5BAVLewmXZM8mauZCUToBuYe3mmzhqs7HLFTT63vI6nzk1degFb1fdZOyOwwXAz/yJ/p666wGldUgs4BsbEscbNX59Pp9+Ms//g4+/9xp60sBADZyOfzJ//l/4PXHCzbrfIxan+oxmlH1rCJ+cRXxD1vdZXF/IPYFsPQHE8R1PoCG+AcbruqwXHk+jqAxn7bAxbzzepI+Af/wr/5oR+EBgN5oFD/8H/8nfHnQXDfdPdlzerM6ivcIq2Wrqem0XnwobYELHrKaHPNvXn0WT52Ysprr8u+//8dWk2NUgUVxymjmTul6qPjsA7jAFMC4r0gFgIQg4Ptff9lq3pGp4WH888PHrWbHFKfCVhOlS3ElPqxwwGqidCBefk9PpxKIx+wJwLOT3nldxUPU8+kU3E6xcCU+jqAxn5bDCqNWU0sZTXmXFVUF1nVxG6U+Qtretdl9Fc4irXBuNYzPu4vfCdmitwVscsxdipdSHydTLNzQcvGhtBbWY+G5n7XfdvbGgrvWC1bEfur57AWo+Ox1GG8v1Dv5An7xwVWreVf+8sZlq8kVbt19SmdAv0WKbf7d3201g2vEf/zRD/GwYN9b2g0a89kbUPGh2ObD9XX863//F1bzE/zn19/Av3nrTauZQgGo+FCc8v/enMGX/uf/1Wqu8u9/8Hf4lz/7R6uZQqniSnwYjjZ62s9cXNt5Xs/bs82bv8dWVKuJ4gF2z6vb4S8VH0rX0Y6Wn/sBu/O73Ab+3T2a0vFoMq2ronQmVHz2OJpaAbS95SkEHj651jul+2ip+GhluppoO1D3WN9sOuzaG7RUfCjtQRX3zvpofFa2HRildCZUfPYBannGaupaQrN5q4nSpVDx2Qeo0io0JWs1dyVUfPYOVHz2CWqpeXU3rYLPSQgs0GDzXoGKzz5ByX9qNXUdkRubVhOli2mp+DCCt+0dKORoShZq4abV7JqZ+WWrCQCwVvE2I8WKKmKfbVjNlDbiNvDfUvEB667tIsUd6uYHVpNr/vzvf2o14ZeffIaL62tWsytin623vNnVfsPuumhuSx64eDz+b61GUljhgN6sylijy7ytXbdr2y0DqJsfGgZKy1ErABcAExiAxgCq8U9jAJXV11jTmK3vjzW/R8ZYy8nYb36XDKPhs/QaPv70Ku7NL+HXV2/gb95+F3/2y59X9zPGrcaYz6//05/T/Ge+Rr1/AJ8XkXpzCYzieIk5CgGbTychx3xb1yxqrt9aDBuflRG54bxdiivPZ69kUPYT6saHgOz8B1OPNx8t4395/wP8uw8+wP9155Z1t2tSby5Sr2cP4kp8KF2IWoG68nOrtWOJXUkjsFiwmil7ACo++xCttAht9R2rueMQ1spIvPvIaqbsEaj47Fcyl8FkvR8ieYWwVsLgj7q/NomyM1R89jHsozfBbd62mtsOKyrof/0ejfPscaj47HP4pTfBZTpHgIT1Ikb/6zXwOdG6i7LHaL34sO5aL1K8R1j8BQJL71rNLSf0YAODr90CK1KPpx3IMZ/VtCvCqrs/EO7Ex0GTKlrl3JkI6SuI3v4BWLE9EzcTF++j/+d3qPC0ETlqT3zaWuGsSitWE6WL4UpriN/8AYJLl6y7mkbg8SZG/+5jxK7TrNZ+w5X4UPYejCIiuPQJ4pf/GsLqXetuzwg8zmDw9csY/Kcr4PP2GpdT9gZUfCh1YSs5BGffRuyTv0Hg4WdgK+4L/VhJRvjeEgbfvITBNz5F4HHGeghlH8FMTEw4njDDCqMQEt8DGECDPudDgz6fx5z/oTH605tzguTV16AVaf1GN6JEEpDi/RATA1BivVCDQYDRwLIqNEaFymqQWA0ao1bt/rU0fNlN8KtrCCw+tj4lpUMQ+wJY+oMJAMZcO/2K1ufXVTFt+vbg3y656q/kTnx8fRCSf2RLfJTND6Bm6OTSvYIc7QV8PgDG5FHoP1h+cxOsJFkPp3Qo5dEQlr871lLxcTXs2murIlDsw+c2wK+vgF9fhW9tFcLaKoR0mgoPpSGuxIdCoewN7PbyQbtT7U5geLrEMoXSaYgp+8W/bpuJuRYf2z196PruFAqlLeJDoVAoXoiPbejcrq5DDYYhJ/pr/vVBTvRBSm7/Jyb7IPX0WB9O6QLKoyGraVfcZLlMXKXaAUDo/RbYwBRxql2DBvnBn297Dkr7kHoHoPEC5GgvNN4HOdoLBoAci0PjfYDRhxnQwNSmYRlAZbRqal01vlu9J7T+nbOyCF92E4wkwbe5Cb5UAFcoQkh721ye4p7l3x5DeSREnGoPLBQx+LdLNfvs41p8+MgF8NHnqfh0OBovQO4ZgBxNQI70Qo70QgmGt4mJuc2g5kfnQny2/ZDNhvLG83OlIvjNLIR0GsLqGvgMHb63k6U/PGgEnfe4+CiLfwFNpj+2ZqL6I5Djg5B6BiHFB4FACJpZCGj8uKorUbRBfMznZ8xbWYJvNQ3/0gqE1TVwBfduPYWc+/962tgiE5/4B+uIv79es88+rpbOAQCG6wEXmDLuGDc14rPt1tjWSnMAFR/PUcIJVEZPozzxNEoTT0FKjkEJ90LjBUNAtn8PO23r4rBlNx9rtesitn17S9C29pm3DFPzMuZzmvs5FnI0jNLIAPKHx1Ea7YfGseDKIlhJNg6iNIvMc6mtO/W+v1oYPebjNu7jOuCsKXQJ23ai+iMoTzyP7PnfRe7Mt1EZPg4lnLAe1nVI8Sgy56bx6BsvY/Xls8hPDlsPoXiE2BewmhrCZ91XsLsWHycwQo3KUhwh9h1B7tR3kDv3e6gMnYDqj1gP2TOURvqx9twJzP/O55A5NQk5bP9ioeyMKtiXAX7TvTdq/1UtqOKC1dQYmm53hOqPojRyHhtP/XcoTr4CJdT9Ho4dVB+PzKlJLHz7RaQvHKMi5BF226fCg6kV8EJ8nECnWNhDFaIoHHwVmdO/j9LweWgcXfM+PzmEhW+/gPQLxyBHqAi5wYn4uJ1aAa/Ex3aVMxUfIjROQOHAC8ic+n1UkkesuykA8pODWPj288icmYAq8NbdFAKcTCr1gvaIDx12NaQ89DQ2Tv4hyv0nrbsodcicHsfCbz+H/NSAdRelAXYnlbrNcpl4Ij5Q7blgNOC8M3JkGNnj30dp8Ck6vLKJ6uORfuEoln/jNB2K2aCrPR9VdtBUjHo/29A4PyrDL6Iw9S2owt7NXLWC8kAPlr51HtnjND1Pwr7yfAC6flctaiCFwpHvQUydsu6iOET1cVh/ZhLLXz0FOWLv4tpPOAk2e4Un4uNk/S6Gj1pN+xI5eRrFw9+D6qPnoxmUB2NY+q2zKI7tr7IEUuwuFAgAgYed5Pk4WLl032e8OD/E0S9AHHrRuofiMarAYeWL08icO2Ddte9xUt3sFZ6Ij5NG8vt62MX5IY5/G0r8qHUPpYlkzo5i5UtHoQrtCbB2Ik6CzZ0V86HpdmK0QArywd+FFkhad1FaQHGsF8tfO04FyEDv4UMOK7qvbDZpm/gwgRGrac+jBVKQxr8NjcZ32oqYCGHh985CTNq78PYidj0fYcVBiGUHvBMfB0Ov/eT9aP4UlLHvACyt3ekEVIHD8teP7XsBsptm92JahYln4uMk6Lxv4j7+FFQqPB2HLkDT+1aAnASbvZhQauKZ+KiVh1ZTQ/ZFpbMvCo0KT8eiC9DRfSlAjtLsHgWbAQ/aqJowXAzCwL8gaqNa3Zf9DMr62zXPssdg/cCBb0MLpKAa50Bl9DaiKgOorN6GVGX0f0xNG1LzWBj2rRaA+jZrbJvnunpezfNd0w5TYwCW0Txpo8pvrALQ4NtY1V9DlsBnM8ZrGmxrvakj9fRAMyZ+SqkkwGgQU8lqG1UY789sx2qeA9Sek22fsbbNp6bfMgC0mu2q3Xw/5rblGGhgJRmDr92GsObdxdXpZJ7rQ+bZ1Nb3D9Rs157frX2j/88DTxqJwUvxAQD/8J/ZEh+UFyEv/93WE+w1Rr8DhIZ1ITHOQbeID1vJg89lwOfW4dtYAVsqgC0Vaj6cNyihIOR4D+R4FGJfAuX+RFvEB4wGVpQx+NqdfSNAK18fRXEyuvX9AzXb9cVn4j/M1Nx3h6fi40t9D4wwQiw+jCpCmv9PNc+wd2D6XoYWPwOYQmKcg04VH65SgC/zGMLKQ/D5jaYIDSliXwKV/gSKo/2Q4pGWiQ+gQVgvYvAf74IVla03tEdZ+GeHjKGXeS5Qs/2k+AQWihj8wWL1vltcN5CvhRUOgPH1NWwgb94yDActf9PR3LBOhglPAn0vG3dMcTBujSbqWyKwtW3aq48xbpma5zGfs9rU3XpezW3zvnFbr4E8X9hAcP46orcvInTvKoTVBXDFLBjZG7faKVyxBP/qOiKzDxG+vwQhk4McCUIJCLt+xobb5v1d7EqIR+lAFOHZDBjFs7/LHcn6yzXtR+qcC+t2YKGE0Kx3f5Q8CzgDAGzW+gAA9tocLz4GduBLVmtH4V+eRc/HP0b8ox8j+PAW2LJ3Pyiv4QolhO8tYeinH2D0R+8ifnUOfKFsPcxTxGQQ6y/s7Tq08kjYamqIV7EeE0/FRxUdZLyCo1ZTV8P2f7FjM1vC41nEP/wHRG69Bz6/Yd3d8fCFEuJX5zD6w3eRev8mAit6oLsZ5I8kkD21d0tBxJT9NLuXmS54Lj4OCg33Urqd7TnbkZXbvs3HiF38e4Rvvwe2nLfu7koic48w+MYlDL7xKQKPmyNC6y8Mozy8N3sriX32igvhcYEhvBYfqBVAE63WXdkrhYYMHwPb+5zV3FYYRUTk5i8RvfKzPSM6VgKPMxh84zMMvn4ZgcferyG38tVx21MQugG7ng8rqp4WGMJz8QGg2e3tw0f3xDQLNvlyRw23fOvz6PnoB/CtzVt37UkCjzMY/KfPkHrvNviCd3+hVYHDym9MWM1dj13x8XJOl4mnqXYA4KLPg489X42S75pqN/Yrj/4eWtm7FF6rYQKj4Ia+s/X5WD11rme4Wp9qD967CP/SdevbdIXq80HuiUGO90Dz+aCEg1DDQWOvngaXemOQfRxgvvdqal+DL5MDI0oAAwgbObCShMDjjL4tul+ArhZV4JE5O47ssSHbqfbqLfRzaT428d4SYlfS1dfoZsojYSx/Z9xyXsy99VPt8Q/WEf9gzTzIEzwXHzYwBV/ym9UPQyI+auYi1I0Pa56lu+CG/xCMP7n1+dokPowqInLtJ+AK69a3aBuppwdiKoVKKgUxlYQm8GCq1c8wXlu/b9bg6J9Tf39W8THubf3ga275QgmBx5nqPz7vTTZLTISRfulwzdQJ5+LDSjKG/2YGfM5eWKETyZ5J6ml2G+LT/4+PEJr1dujuaZ0PAEBTwEXObX2Y2luLrfpDVivQCneNnd0FGzkGNnrqic9n1vCYdl2IdLt+wW4dY26b9upjjNvqeap5TmudD1dcR/TyD8FWnP9AlFAIhclDyJw/j/yhI6gMDECORKBxHBjjfVTfi/Hatfdh+ZymrbrfvG+5VQUeYiKM4lgK2WMjKI4lofEsuJLkyiviShKit5eh+nlU+oySDtL3ZW4b9zWegdgXRORW92UJreRO9erDLutn3WW79901z2M+TRCfCvjoeYAxgnT1vmzjljH+Y7gw1M1PjJ3dBdf3TYDzP/H5rBdfM8WHK60jcv0nYGRnf5WlZB9yJ89g8/Q5VFIpaD5jwqHl9apvoea1a+/DofhUb41tJehDaaQX2ePDKA/1AAwgrDuvRQouZhBYzqI4noDGm2++wfsyt2vsckwAKyrwP/Y25dxq1l8e1IPo1s+6wzaflT0fcqEZAWfAwQx3VujKJZTZ8PG2F0lyxXWEr//YkfCowRA2L7yKjQuvoDwwZN3dEZQHY0i/dAjz338OmXMHHK9KGljexOjfXoKwXrTuskXmmQHI0c5JLNhF9XO2Z7N7nWI3aYr4OGksxgQ7rz6mEVzP81ZTS+GK6wjfcCY8pcPHsfH534SU6I46K1XgkDk7ioXfPYfMuVFHbVBZUcbwD68gMuM8cKwKLNZfHrSauwa7bVPRbeKjVhaspoZ0YnHebrD+0bZ6PVxxHREHwqPE4th86csoHj5u3dUVqAKHzLkRLPzeWWTOjzgSodTbs0h86LwEoXgw5mh6QidQHrb/vgML7rzFnegc8ekyz4eNnrOaWgYr5hG58RoYxZ7wiCMTyD/3OSjRHuuurkMVOGTOj2DpuydRHI9bdzckdm0ZqbfnrGZi1l/qTu/Hiefj9bQKk6aID5wMvfho16zlxfAxsMFJq7klMIqI6J03HAlP4dQz0Hh74/1OR44IWPnyIax8Zcq2FxS5k0b/GzOO2meIqQDy0/ZFr52ofs5+cWGThlxAE+p8TPj4q+Ai54jqfPQ7GpTVN6HlbtY8S2fCx54H2/OckaUya3D022bX+URmXoew8cD6lnalcOo5iCPjgFEXpBr1NzBrc2ps+vdhfif6MWBg1PRo8G1mwcoShNU0wABcoQiuWNI/t4n52avoe+VIEHI4ALE3Ajmi3+5cd2Ns19TaVO/XPV5vBpZ66wFC9+3N9RKTISx/4whUgd2xzmfb6xm3fE7E6F91T4lIcTKGld8cNd6/8ZmAms9Uu63vi322gcRbNh0JQpomPmxQLza0Iz5q7hbU1Z/XPEtnIgz9c4CPtlx8AivXEJp/3/p2dqU4fQ6V8SPVi8qu+Piymwg8egR/Og0h7TxQWw9V4FEeiKM8EEdxLAk5EqgRE1RFhVR8zMfFrq0g8Z69ob+YDGHpu9O2xAfQkHjnMWKXvU9DN4P1lwaRPZOoXn8k4tP/2pLnxYUm3tf5GGhqEXz0mZoPav4l3bplarbB6Ct5apuXDUNnwvj6tj5XvX/Qb/WLe8uuC5FuZ6DfmseY26a9+hjjlgHAldcQnXnDeFIyKsMHUTpyWn9bxmsxNe9FNxivb9oYgJUlBBcXkbj4ISJ378KfToMreh90ZBQVvmwRwaV1xG4uIjL7GACghIStlHrteTXvN7BX+kMoTvTYagjGlSTweRHFiZp4WO1rWLcNKkMhRK9tEL9OO9m4MAAlxNf9HDttJ3/xuGmfrWkxH6iVPRn34ULtyRJF7r1lNe2KlOhH/qT9WfbhuVn0v/E64p9eaorg7AafLyPx0SxG/+4i+n95w9UsdTEZxML3j0FMmvPPGhO5s4bUr+wNaVWBRXGy89tuOIr3pCueVzXX0jzx2aNZLzY4ZTU1neCjS+CK5K69Ggwjd9Zo40qIL7uJ1NtvoufaFbCStx3rnBCaX8Pgz65i8GfXEFh20CHTyIgtf2sKxQnyP2iRO+uIf7JsNe9K5rnObwvjpDSgWVkuk84Tn3B7skgkML4+MBz5D9kLWDGP4JK9qSe5M6/YymoFFh4g+fab8G069zSaRWB5E4M/vYbBn153VJ1stsTIH+217tqR+CfLCN0nPxdy1If8sc4uXygetF+T1qz6HpPOE58O9nxY4YDV1HQi939lNe1KaeoU5Ch5Cjh84wpin31sNXccgeVNDP+3y0h8+MBRajz9+VHkp8kFKPWreVtL6GTPJqymjsKZ59PF4qPHfWxmSFihYwWo1UMuYfM+fLklq3lH5GgvipOnrOYdiVz5GMF73ZMqBoDY9UcY/ZtPEXpgf3a5HQFiRQWpXz4kFjox5Ud51H4BXyuQo4L9+VxNjveg6eIDQC078H46dOjFCq1tdh9+aDOtfuQpq2lHQndvwL9gL7jaKbCigv6f30XiA/tTJNZfHCIOvAprJSTeJRf/Th166QsD2qPZ8R60Qny00qzV1JBO9HxaLTzC+h2wYs5q3pHK8CSk3n6ruS7+xQcI3r1hNXcdsWvLGP6H68TeCYzs1PK3J4kFKHJ7A6H7ZAHv/LEeqP6mX1K2KU7aj1M2q7anlqafKbWyAKj2pgLAnwJ89k9YM2F8ZBe2VwQfkcdhNF4gHm5xuQxCNz+zmrsWYa2I0f/viq34jCqwSH9xlLgxvJ3hV/54Z3k/qp+zPZmUFdWmx3vQCvGB08Bz+KDV1FZa6fnY9XpKY9NQAmQ/sNCVj8B0QCrdS1hRweBrtxF6QJ6hElMBpL9I5mGzFQWpX5D9hjtNfDox0GzSGvFxMvTqsLgP42tdLYd/9YrVtCMaL6B0YNpqrktw5ga4rL15T90CKyrof30WkTvk9VDFg1FkzySt5rqE7mURutd4+CWm/I7WxGoWxYP2RxCtGHKhk8UHwZGOWlKnVfU9fH4JXIn8AiqNTRPV9LClIgIz3q5o0YmkfvUAkTvkDfTXXx4gjv8k3nlkNdWlk7wfJ/GePeX5OEq5A0CkM7yfVg65fBu3raZdIfV6wlcvWk17lsR7C7ZiQOkvDVtNdeFzIuIfNV6Xrjhlf6jTDIoHY/pMfRsI6Yrna7LvRNMmlj4Bw4MNjhvbNTfWSW7bJvAxQK79dSiscABsYGrrve32D/qtk4mlrCIiOE8+q78yNInKwNY5ZYxb8z6MU+jbWEVw5pr5sKagCjwqqR7kp4ZRHogjc/og8lODyB8aRH5qAPnDAyiOJSD1hKAKHBhFJQ7i2oVRNIRnMyiNRaGEaprhW74Tc9ucbBlYbPwXX1grI3cyCY0zT/CTz6v6WYTm8uCKzfl8pGw+1Vffq7P8Rmq3o1czROfBC1onPmoRbMzo/lfzvT1xImq/TKEXyFwGtPZ+iVzgkN421Xxvu/2DfutEfIT1G+Bz5M33c6dfheYzmpnvIj6RaxfBlpyv/rATSjiI4sERrD9zHOvnjyI/OVRtkSFHAsY/v/4v6ofUE0R5KIbCZArZE0MoTiSghHjwedFzIWIUDf7HRRQOxXWhsHw/1vMk9gcQvpttWFjHKBo0ntkK5Fqfyzzviobgg9ZcxDuR/uLo1modtVg+e+124tePWyaa9nwyF2hyFpDJMzhVOmDo1ap4j50hlxQfIMpw+TZWwa83HirYoTQxirXPPYtH33gFmXNHIcbtF7EBgJgIGf2Yz2D560dRHnL2PDshrJWQ+iWZmKsCi/VXBqzmusQvroDP7T40KY+Sz6ZvBk6GXHxOamrnQiv23p1LHAWe94n4sFIObIk8LlYZIpvq4eVwS+pLYu3LL2HzmVOo9Hk7l6k8FMXyN45g+RtHPF2aJnR/E5E7ZFMxipMR4ikSkVu7Zw3FPj/kWONEQLNwEmhuVZbLpLXik3dQVRs+CPi8/YtoF6YFWTd+857VtCMaL6Ay2FiU2XLBE69H8/mQP30cmVeeh9xj/0dth/JQBEu/PY3sKe9KGxLvLjX0VEwyz5EtJRS7vAZW3H2I1k7vx0mKPXKTvE7KC1oqPpq46mzo1eaaH4b37kLYCTtDLrGPbHZ9yAOvRwmFsP7KBRQPta7oUxU4rF8YwcpvHCSuQt4Nc5IoCeWREJH3w1YURG7u7v20S3ycD7nKVnNTsfcOPcDJ0IuJkaWTuxVWyoGzMeQqjTY+H4wsQVhZtJptIfX0YO0Lrzbd29mJ4kQMy9+a8kSAAksF4jlamefJCg8b9W4mEbFm0A1DLrRDfLSsg3lF/pT+b4/C5clnTquBCORI47YQwsqC7QUFa5F6erD+8otQfc6WJ/YKMRnAwh8drZ8ytglpkWB5JERUpcznpF3T0nKMb3ncR/VzthqnmbR6yIW2iI+chSaS/5Wv0tP4r323wmXJ4z1iiqzg0b9E/pxWVJ8PmfPn2y48JqrA2ZoIuhN8TkT8Y7IYWPYc2QXcOPDsXfCcBCexnnYMudAO8QEAzUngOXbMamkJrahu5grknk9lsHGWiy0X4HMRaM5NT0NyONTiC2VE5h4hfuU+Eh/PYPD1yxh8/Qril+cRmV0Bn3eWyhWTASx/230MKHalcaAYAIpTEaL2GKG53WOYrY77ZE/bHyGE5lo/5ELbxKfoYJlaVgD2YOyHLa+BUcguSI0XiIdcThFTKRQm7QX4+UIZ8WtzGP1v72L0h+8i9f5NxK/cQ+zWAgKPMwg8ziD+2QOk3rmD0R98jOH/dhmRGZsrmxgz0d0uU8xWFERuNU69qwKL4lTjVSnYirKrAJEM37xCjgoQk/aHp+0YcqFt4iNnHQmQ1tMe76eZsAXyoLCYIstyuRly5Y6SCzwryYhdn8XwP76Nnquz4Atk86mE9QJSv55x1A41Px131JmvlkaBYpPsObJe2LvFfVrp+WRPkwXKaxHSlbYMudAu8QEArWg/64XgcNtrfryGLZNdCCAUH7ZcAJ+zd0GbVFIpVJJkbjtXLKHvFxcRu+bgezTg8xX0//wuUm/P2Zpekf7SiKvhF58TydpjEBYK7ub5wAg8twLS/tS1NCoXaCZtEx81f9N+h0MA6D1jtXQ1dqqapXjjIYebIVd+8pDVVBdWktH3+nvwZXa/6EiJ3Elj8Me3iQVIFVjiYsCdaBQoNiGZoc5npV2LGEkEzC35o71QBfuC3Eg4m0nbxAcAVAfej9ZzrKP6/LiFLZOJjxwfIOrb49vQlxy2i+rzoTw4ZDXXJfGrDz1fWFBYK2LwtTvEApQ9k3B1UYfmsrsKhglJ3AcNeuCUDzR/6OUkvR6ay7WsfUY92is+Tmp+WAFatHXVts2EtZHlIvF64MLzqQyS9bSJ3LgLPtN4yOIEYa2I/tfJY4FuvZ/QXOPPUR4NEmW9dov7NBs5Ktju04w2BppNGp/VJqKJq45qftTks1ZTV8JI5C6vHG8841pYdSY8AIhjPaG7960mTwk8yhEvV5w/1uPO+7lHdv5Jgsa7iU951H4Gyg6Zpxv/NqywotrWIRfaLT4AoG068H58UWghsubfnYydJvFST+MfmG/DeW2P3NO49WfgwUJLms/HP3mEwCOy2hM33k9gsUBU80MiPnxWInour1H9nKPCwnYGmk3aLj5qcc5R4FlLtcb70ZTGrrlTSNPsJF4PAPAO4z0AIMUai49vlTwz55bEe2TnJn8sRjQs2onAYuMma6S1OjulrEkf7wSngWbScoNm4vxb8wq1ome+bKKFWpN2b6b4MIRpdrmncbyHkSXHKXYlRDYBspXiI6yVyPvwEAaF67FboNiExPPBLs/lRhwb4aT1SGCx2NZAs0nzzooNHA29AKgt8n6aAWOjslki8HycZrkAQAmSBSu5IlkRoVfEPyaL/ZDOw6oHiecDQu9FSJN9n16RP5qwvQY7OsTrQceIj5yFViZzs2tRe6ahtcD7aQZskfzzys2O9xAMuYQ0+XI0JqqfQ366F5ln+5F5ts92iwk+JxK1wRBTZMWA9RDS9YdKVsT+xhNEd/MmmlFo6CS9zuektgeaTTpCfABA3XC2tIuaaH7RYTOGXqTxHiVC1q7UledDMOyyG2gWk0EsfH8a6S+MIvNMHzLP9mH5u2NY/p0DtoYhkdtkokdSDLgTu2WqTEjEbaeYDwDIPY0fb4fycATlIfvDTdLiylZA/itoMlpp0VGXQzU+DXCNXWI3eC4+qgg2Rzb/isTrAeA43gMAcqzxHCY7tT2qwOlNwOoEQssjQaS/0jiGZRK6R1YMaNerqoXE+yFtjUHyXr3AaXo9dplMzFtBx4gPnHo/rAA1cdpq9RbN27E8qfAAgExQXOjLOB9yAYBIUOPDb5KLT/ZUf13hMSlOhYliKCahe42L4dx4PrsNl0xIvTWS53KLmAw68npCc1mwFbIK8lZAdkZbhJa76cj7URJnmur9qJL99g+7weTIqng1XoCUbDyZ1M2Qi8TrAQCu0HhoYlIebnxh2ImBkEwChY2slBUSz4f0ufmsbDV5Tva0/QwXjCV/OomOEh+YAmQXVoDSRO/Hy2EXI+WIPR+JIMUOAMIqWXP0epAEm2HT8yFB7Cf/YxFY8i4jVQ8vvYFmez5yVED+iP1Ac+hermVDQlI6TnzUzGVHRYfN9H40pbHbTwq7fsVq2hEpOWY1PYGb+h4AkJKN/4oK6fanZkkEyKn4kHg+sOmtNYvMU2R/kKx0Snq9lo4TH6gVaBkHdT+sACX1jNXqCarofM7UNlQR3OYtq7UuGi9ATDUWH78LrweE4mMn2NwsSOpxSIPCTiHJeO1UaOgFutdDlv2sJbBUIDp/rabzxMeF96MmTjet7kfzIO7Dpi8CpIWFyTFoXOMfu5t4jxoMQQk2zhLtdc8HLcxSuWH9grP5jJ3o9aBTxcex9wNA6WtO1bNb74eppMGuX7aad6Q8ctxqqoubmewkXg8ACE2YVmE3zkI6NHIqQM2O1bilPBxBcYIsPleLXlTYfs+1Hp0pPgA0p95P/Ci0QOPUsV3U8ozVZAvm0ZtW047IPYNQwo2DioFHc+7W5iIQH65Ysl1gSIKwYu99k4oVaUrcCXJP+2I+mafIGr1Z6bQMVy3N+6bcolYAh96PPPiS1eQaVVxwnPViVt4BUyHvW1QZIGtnKqSdez0AIA40biAWeEQ2v6oWMUmWlrYLydCrmV0DSWI+u1U5O8VpNTOfk4hW6mgXnSs+ALQNh95PaBhq2Nn4eDfUooP1xrK3gA3y4Zbqj0Dsbyw+bLngKsWuxOJEbVmFVXLRNNmtwHCvw1a87+mzfsHZ2nHxjzrX60Gni48b70ca+YLV5Bq5cAnQbIhh5jKwTD7cAoDCETKvLbBsv/91LZWRCaupLnaDzaTCI6ySBd5rIcnYNHPY5QZhxf7nBYD8kaQjT7LTvR50vPgAutfgwPvRfFHISY8LD9UK5MyvrNYnkXPQHv0EWP21dc+uyD2DkGNkdRyBh2Qp+50gGXIJ6TXb8R4x2Th7hiZ5CGhBut0pTj6vKnDIPO0w1tPhXg+6QnzUiu5BOEAeeAaax4WHSvEGpNUfQKs8OStdK85BXX0Tyv2/BPJkUyhMNF5A8TCp1+Mu0KzE4lAJUuyBR4+spobI0cYXfyumIOwFsqf6IUcan08rgaVCx3s96ArxMWM/Npqtm2isAGnoRavZNWplAdLKDyDN/2+QH/w55Pt/Dvne/w5l+cfOpocAKB84B9VPFlQM3SOvkq6HSDjkCizZDzbL0cZi3+lpba8JLNhvwiZHBWTOO/V6nNd+tZKuEB+oFWDNwYx3AHL8KJRw4yFGO5ESY6gMk9X1+JfnwJbJmqvvhDTQOBjv28yCK9qv1iXJyjiJ9+w31i80nlBcj06tZq5Hd4gPjKyRjXR1LeIQ2XCmHSjhBAqHX7aa68LIEsIzH1vNtpAT/URDrtD8vNVEBEnMp1s9H5Jao3p9hQIL9tLv5aEoiuNk3QasdIvXg64SHwDM6jtWExFqIAlxoDnzvtyg8QIKR78EjSMb1wcXbrqK9cBGlstJvEdMhoiyXd3q+dgtjDQhES0TVeCQ/hzZd2QlcnuDqBaqU+gq8UFxEciTtaOwIiVPQxWaM+/LCRovoHDi68RxHi6/geB9Z4F3E433EcV7fFlnQy4SrwcOYyDNhqSA0Cl2RCt7asBRkJkVla7IcNXSXeIDgFmxl7420TgB5VHva3+coISSyJ/6DpQQ+QzlyO33rCbbVCaOWE11cTrkKg81XrwusNh5wgPA0SoQpJB6emIy5DjIHLuyBj5HLnKdQNeJD6Qc2LWPrFYilPAwlAPfBMM3vkiahdh3GPnjXyP2eAAg+OAKuLz73ruVYbI17oMOxac43ng+GumFWA+SIV0zIanVsU5s5bMy0eMAYP15Z0FmPichdtVZPLSddJ/4AGDWnaXeAaAUHwV34I/BD/8h2MgxgG2cGvYC1R9F/vCXUZx8hTjGAwD85mMEHrgbbsEQHqJA88N5sDYLCwFATJDFe9z0uxH7Gq95bje4CwBiqvHzglA4Vf/2c0A6xMyeHEB5yFlYIP7xsq24UqfQleIDtQJ2xWHwmQEKQRmMkALb9yXwE/892MGvgwlPWg/1BI0TUBo5j80T34HYO27dvStcYQPh67+0mh1RPHTSaqpL6KEzryd/uPEMebgUn2ZhFQwvIREfOepH5ryzcpDAUgGR251fUFiP7hQfowk74zD4LPIaKv6tvxRM+CCYoa+BmfqXYAa+CETcC5EYn0Bh4lVsnPtjlIbP2/J2AIBRJETuvOM6uwUApamTUAONvR5fdhNC2pn7TjLkCiwWiYcg9SgPN16hwkkanyTYLKySfQ/WRvMk4pN+5SCR11iPxHtLVlPX0LXiAwDc4187mvcFAEW/Ao3TthtZAYhNA8O/Ce3ov4J68PegDrwEJXEGWmik7kx5jfNDjgxD6plAeehpZI98E2vn/yXyU19GJUkW4LXCKCKiV37mSZxHDYZRGj9qNdclMutssmp5MAY50nj4Gpp1XhxJMm0DAPhN+1M3SILNToY1fFZuKIbZk4POh1ufPIaQbixunUpXiw+kHLhVZ8FnlQE2g7v/oDR/CmrvGSgDL0Ie/y1I47+F0sk/RfHknyJ/6k+RO/WnyJ/4ExSmvoXiwd9AafApSBFn2QoTL4UHAApHnyJqncGVigg9fGA1E5E/3G811cXNMr0k3gkI4zJWSGJJpPPRyiNbHmYjsRWTIaw/37hPdz34vIjYFfetfdtJd4sPAHb9MpiiM9dTYTWU/c6HAV7DFdYR+/RH4AreCI/YNwqx70lvrR7R285myasCj/yhxvEeIV1u6AXsBsmQC4QZKSskQx4S8bHGjiI3dm8+l37V+fA+8e4SWHH3P56dTteLDwBwj50FnwGg4FcgW4dfbcC3Po/ItZ+Brez+15IUNRhG/sQFq7kufHYTQadezyEyrydy093yQyQZKZL4Sj1qvZWdIOnHU5tm57Pyrl7Y+vPjEBONX7ceoftZhO67O5+dwJ4QH6acBpd2NvwCgGxQgcpYra2BUUSEZ95B+OabngSXTbJnXiUabgFA9LrzWfLZ42RZmsitjNVki/JI47qo3S72nSAdzpF4PrWxo928nuJ4L7In7K+1DqOSOfVLZxnJTmNPiA8AcKsfganY67pnojEacoHGPy6v8a0/QPTyDyGs3LXuckX++AXIEbKJif7HSxDWnMUO8ocGiALNkVsZRwFbEzEVgCo0/qmSZqRqIfGoQChstbGj2Kf109+qwCH9ypTVTEzqV/NdP9wyafyNdhHc0puOs18yr6Hssx8vcAKfW0b4xk8Quv1zz4ZZJqUD0ygPkcUSGFlC+LrzAsbMWbK6JddeD8Ha73A47CIRHxLhQc2wK3Izu2PsaeVLR4liTPUI3d/cE8Mtkz0lPkw57Tj7BSP9rjj7XRDhT99F5OZPELnxY/BZ+7PGG1EZmkLh8FNW846E7t4EV3JW9JefGoAcbuz1CGtl1/1l8tONa4hI0tr1KI80DmSTDLlQ4/nEP6jvga8/N4HyoLO0OisqSP1qbwy3TPaU+AAAt3YZrMPsFwBsBiUoHsV/GEWEkHmA8L230XvprxCee6spogMAlcEp5KfJAswAIDxeQuCe8+Fe5kzj2fEAELvsrGjRRPVzEJONvROnldMkaXYSz0fs04eGsc826opgcTyB7Amy/tz1SP3qwZ4ZbpnsOfEBAN/Dn4JxOPzSAOTZFWgrb4FNfwSmuEQkZqyYB59/BP/aHYQX3kfszmvo/ewvEZl5Hf70HTCKs/dDQnn0GHI2hIctFRG+6txDzJyeIPJ6vFhBoThBNgk4NGvfuyKNJZEM58SUH6yoIv7Bk2IrJsJIv+w8zhO5s76nhlsmzMTERPvzzE1AjR1EZeyr0AxB0ZitWwZa9T4YrWoHAM3Y51+7g8gDgpUq2kxh+gWUB6egQQPD6MFzMPrnYqDfgtHPAstoYBQJ0Yu/BJd1FodRBR4L33lev2hZDWDUrX+sBjBK9X7qV/Ou5x0tfe8IxJTf+BzQv03zMxmfC4yGsf80s2OcZSeyZ5JYf9nIOlWfz9g2XwfAxH9o7CGmvzSE0L08QrPbCylVgcfyb56oWf6m9nOYR5m/UvO1t+x8QcTwD27uOa8He9XzAQA2ew/8mvMUciV5BJX+U1Zzx6DxAnJPfRPigL2/qKGbnzoWHgBIXzgO1dd42WA+L7oWHjkqEA25QnN528IDwngPyZALxrw1q/AAQPrlKcf1PADQ/0+ze1J4sJfFBwB8j94FW64f/COheOACxDhZbKOVSMkxZJ79HaL13GsJzl6HsHjfaiamONqH4mjKaq5L/GP3vYSzpxpXToNgGsNOkIgPyZALOxRRrj93EMUx8oZxVhLvL0BYI3v9bmRPiw8A+Oedx38AoDDxKpRQ0mpuCxovIH/sC8gf+zw0jqw4zsS/dB+BmetWMzGqwGP9KbKJssJaCZHb7qaIqAKH/NHG4sqK6q4FfTvhZbynHvlD/cgedz7PL/Aoh9i17mqLapfGZ7/LYcQc/Au/sJqJ0TgB2SPfsN0Sw2sqwyeQffp7kBL2JyL6l+4hcu1Dq9kWa8+fhBxuPASC8RfbLdlTfUT1ME69nuIkWSDbSRatPNiD9EuHrGZiWFFB/+vOOgx0E3tefACAy96DL+08/qNxArLT7REgse8wsud/F8WJZx29vhfCUzw4jOII2RAocmcNgSVnglBL/ijZcCX2mTMPq3iwsfgIqxXbsSQxEcbKF45ZzbYYfO3Ono3z1LIvxAcA/I/eBVdonDLfCSWYRHb6G1ZzU9A4AeXBk8ie/T2Upl6x1e+5lvCdS4hc/8BqtoUUjyFzbtpqrgsrKki8/9Bqtk3+SIJoBQchXSEOCNciRwWiyma7Qy5V4LH81VNEHttOJN5/CGHNvrfVjewb8QGA4IOfgXXY+xmGABUOvmo1e4YYn0Dh4KvInPl9FMeedyw6jCwheuMDBOadtckw0Xw+ZJ49RZTdAoDUW3Ou/2KrAof1F0at5rrEPnXm9ZAEmmFzSKcLz0lXwhO5u7bn4zy17CvxYZQKgvd/5qrgr5I64pkAaZwfUs8E8uOfQ+bsP9O7H6aOOBpemXDlAnouvQH/0px1l20yL5yHFCebDhCa30DogbvUOgBkT/UTXcB8TqqbYSKheLDxZ2JFldjzMT0eMUEmavUQ1ktIvL+3pk80Yl+JDwBwpTT8S+9azbaopA7bFyDODzU8Ajl5GpWhF1E48j1kT/4J8pO/gUrSneCYCOkFxC/+BHzOvQjknj4DsY8s7sKKClJvuw+QylEB2ZNk/YHiHzqbia/6OaJ4jx2vZ/mrpyD2OhceVlTQ/8aMa6+x29izFc6NqAw+jfLA0ztWOAMAy+j3AWxVo5rVqQACqwuIZjL6MQwAPgoIUf35WP0oNTwMxajOVRlAZTR97hij6fdZDSqjbb0Wazw/A70i2aha1sxto/JWM/ZrjAZNkRC59S6EtPt4CwAUDx1E4cxxqIwKhdWqtxqjGpXAtRXNKvp/cROheWdDoFpWvjKF4njP9grjbf+gV/3mRYz+ZeOq43rkp3uR/sLI9mppPFnh3P/aIpEApV86gvyUIZiW6uTa38rWvicrnIf/4dq+ifPUsu88HxP/8scQNm5bzbYo94+iMvgU2PhzYOPPgolOgwmOAMERIDgMhMgabbnBt/YQvR/8vWfCUxo/gNzpE1bzjsRuLHkiPMXxOIrjZD2I4hedeT0AkD1NVrNFkmLXhcdZUzCT1Ntz+1J4sJ/FBwACi++BKzmvgAaAbKyCUpCs5YKXcIUNRK68jsi1X3nWAbE4NobN82et5h0JPN5E4qKz5YtqUQUO6VfJVlPVYz3Opod4OV0j/aJ74YlfWkTkzpMTUfcL+1p8GKWC8MyPXAtQISaiFGjNeJ2t5BG++y56Lv0IfGbZutsxxQNjyJw7ZzXvCCvJ6P/FDavZEelXJ4mCzACQenPRaiKG1OuJ3Ng9kJ1+8ahr4YncTSN+yfln2Qvsa/EB9J47oflfusqAAUAhVkExsPtfSzfw2WWE7r6Dno9/AOHxjHW3K0oHxpE5d95q3hFWkjH4+hWwonuPL3tykGjBQQAI3cu6akxWPNhjNT0BK6q7xnrSL7gXHmG9iNTb7rOR3c6+Fx8A4EpriN79kWsBKkUrWA+7vyBNGEWEsHoX0Ss/RPTaTz3v9QwAxYOHkTlLLjwAkHrvFoT1nS9QUsREGJlzZEv7sKKKxK+de3r5o71EiwPWm5kOI52+8vmTngjP4I+98Ri7HSo+BlxpDZG5f7Ka7ROUsBZ1J2JC5gHCc28j9ulfIzj7tmfreFnJn3kG+ROnreZdSb1/E6GH7uMUqsBj5UtHiIdb8Y8eg885P68kk1QBIPbZk2UKqsBj+StnUDxANmzbCWG9iMGf3Nh3KfWdoOJTA59fQtiDBmKcX8FG5MlWmjvBinkIa3cQmX0DvZf+EpG7bzS1+6HG+5B/7nMoj5A1gDeJX72HyJw3bWBXvniUaOULAAgsFRC77DwuJ0cFokUH+ZwEYbW8zWYKj9jrrNrcxKyFosKzxb6t89mNSvII8uOfa1jnY9rYGhtT7U4HqCKHSJHX64aMOh9U0tCkHLjyKpjyGvj8YtNEph5ytBfFU89A7emBzGhQWQ0KoxodEDWwrAqG0bse1tb5BB8sIvmB85YctaRfPqSvclqtGQIAo4aoWntjvB9JxvDf3nXl9aQ/fwD5o/Ht9TV16nwSv368baKq2BtB+oXprcplBoD2ZJ3Ok7U8tfs1sKKCwZ9eh7DuPF61F6HiswOV5BEUJz7nSnwADWw5i+DsR+CLy4BifxKkl4j9o8iffA6MjwPDasTiE3ywgN4Pr1mfzhGZs2PInBvduvAbiI/bVqyqwGH+T04Yr4UdxYeVFIz+xUx1fTGxN4Llr5zV57VVBcq++LCiTIVnB+iwawf8a3cQvu9+CKYEYyhNnoMSaOz2N5PCkaeQO/My8SqmJqH7i54JT/7QADJnD1jNOxK5s+FKeAAge5qsFUhoNlcVnvzUEJa/co54Qu1OUI9nd6j47IKwdgfh+29ZzbZRQgnkT34NSphsrpSXyJFeZJ79GkpjR627GhK5MYP4xatWsyPyhwaQfvGw1bwjwloJiXfd1cGoAofsKcK2r0bVdHb6ANIXpj0SnmtUeHaBik8DdA/IvQBpnID8md+C2E9+AbqlPHoMm898HXKELNNTS/Tjywjf8Ca1n58aQPpFshasMIOzHiwLnD1N1g0xsFgEn5WQvnAM60+5/35YUcHgz6jwNIKKDwFeCRAAFA+/hNLB56xmT1EDEeTP/AaKU09bdzWElWTEPrmMwAP3rVABID81iPQL9ryu/tfnXDdOt+P1xC6tYelrzyI/6bznsokuPFep8BDAxePxf2s1Up6EL66BFfOQemtWszACjrVB5u0B5+2Basa4VaJ9UCIJ+DKLYFR3f92tlMfO6g3mg+Fqls38x1Rv9RnyKmOsZ2YEY1lZQvKd9+B/7E1Dq8zpCaw/YyztU3Metm9vD+Cm3nrgyQJ5m2cHUDpQ07fnidfVN33rCgrDh7b3p97lO6x7a8BKVHjsQD0fG/jTdxC+540HJCXGkDv5Vc/iQHJsCNmnfhflA+QTQ2vxZTfR/8Yb4DfdX/gAkH7hGDKn7S07FLu2gsgd5/U8JrrXQxBoroQhsaOu4zugwuMImmp3gN7N8JXqX77dUu1mbyDUrJRa3QeAUUWE77wD35qzLnaqP4ri1CtQYoPQjP46GqOBMfoEaaze8wesBsZMpzPqtlS7sHAf8c8+sT61I1SBx8qrp1Ee6NmeNmdr0ui1KXUj1R65u4rUW+5nyANA+nPjyB/prUl9m69lbIMBSjFADNTYaqh9XO19BnVT7cJGHv2/uAk+v71AkbI7VHwcIvaOozD5KjROcCU+5g/Yv3QDobmL5s6GaJyA0vBTKA+eAMsajcZsio+iiAjf/AyBhw+sT+8IsTeK9IXjele/WoFpID6RmTRSb3kz0VJMBrH029M1r43t4qNwQDEOqHyNgDgXH2GjgMGfeTPJdr9BxccFSiiJ7LGvg+EF1+IDaOCKG4jc+AXY8s6TNjXOj0rfKRQHTgK8D2A1R+LDFzYQvPIReBdLJ9dSHO3Xl1IWuO2i00B8IjMrns7wXv7mEZSHwjWvja1tMQyUjGkS27wXZ+ITWlhD6p07VHgcQsXHJUooicKRL0P160WEbsRH/8ssIXK7zjCM80NKnkal7xRknw+KKSYOxCc4fxuhW59uf34XbJyfRvbogWqVNKn4RGZXPOn9bJI/kkT6c+OGaNSKD4BCLxjFZ6lYdy4+kdllpN69U30IxT5UfDxA4wTkj38dSijhWnw06L2ZhcezCM5+BEZloCZPQ06egcT79OkQxj+74sNV8ohc/wC+dW+yWVI8ivXnTqLSG9V7SdsQn8jMClK/9q4vkSpwWPiDk1D9hudlvpbsB4oxsGAMq3vxSXw8i9hNdwWQFCo+nqFxAopTr0BO1M4Udy4+AABZgZCNwacwUBlAZo25WA7EJ7hwC6G5q561XC0cnsDmqSmoPs5I2ZOLT/zyPOKfetNz2mT5G0dQHopsF5NSDzhJMM6zsVCAC/FhZRmJizOIzD7eOpbiGCo+HlOeeB6VQbMBuzvxMS8UreRHuCA4Eh+uuI7wzffA593NkTJRwkFsPnMa5b5eqIag2BGf1Lt3EJnxxvMyyZwfRuapoS0xkfxgS1GwmlHHBPfiwxfK6P/VdU+aqFF0qPg0AbHvMEpTr3gmPmCMLE3BD15hiMSHVUX45z9DYOGm+QKuKR0+iNzxw1AFDip0ISQVH1aR0f+L6wgse1NHZFIeimL560f119H0FDovm5Nn9fPtVnyETA6Dr1+mgWWPoeLTJJRwEoXjvwmVNxYDdCk+5pfEVQRoZX5X8fGtziA0d9GzIZbYl0T+9HEo8Zg+lGM0W+IjbOSReu+2516DKnBY+u5JyBEfIAXAl0NgNGb7OXYpPrFbC0h87F1sirIFFZ8movEC8ie+BiWU8Ex8NAZgVUAr+wGF2SY+XP4RQnffBlvx5iJXQiHkjx1BeXwUDPTXsCs+oYU0Uu/daorXsPLlwyiOpoByGILMG+fJco4dig8ryUh8fBeRWed9oym7Q8WnBZQmnkNl+IRn4mPu8ck8FJGHkH+EwMIl8FlvWpyqPh8KU1MoHpqE5uP0uWAOxCfx8V3EbnkzQdXK5ukRbJw+gkAloAsOzPPkXnyETA6p925C2PBGxCn1oeLTIsT+wygffHZrGOaB+DAMAEVG5O5H8D/ypl6meGAMuWPTUELBGtGxJz58oYT+t6407eLdPDGJwvEjYI2T56X4ROYeIfHJ3aZ4apTtUPFpIUo4geLhl43JpB6Jj2HzZR4jdO8KfBvO0sClA+PYnJ6GGgzq3os5+92m+ETuLSHxSXOqfqW+JLLnTkCORarCAo/EpzrM8qhBPqUxVHxajMYLKB84h8rwMU/FxzwisDyH0NwVsGWy2dVSsg+bZ5+CFApCNeJSTsSHkSUkP7iG0ILzddR3QgkFkXvmLMRUoioiXoqPsJFD/1tXwBfoxNBWQsWnTUjJMRQOvwStZhjmhfjAEILgw1sIzt/aMeMlJ/pQPHIclWQKKqPXBDkVH//SCpIfXvPc21FCIRSOHzYC3ttFxCvxiV+7h/gV7+aWUcih4tNGVH8EhSMvQe4Z9FR8zFtGFhG58wn8S1sXl5zoR/nwcYiJlC4ihqA4ER+2XETvh9fgX/F2UUNddI6gNKZn2cDoH8tL8eGLZfS/fRnCRv0VSinNh4pPB1AZPo7S+FlovM9T8TFtXLkAIb0ANRaDnOgDY4iHG/EJ37iL8J37YCXvvB0lFELh2BGUxg9U33szxCd2ex7xa3Oee2oUe1Dx6RCUcAKFoy9BDvd6Lj7Vu+a6XKzqWHx8j5YRvXwDXMFdj+VazHqi0tgB432iKeLDFcpIfnANgRVvpppQ3EHFp8MojZ9FZVxfP9178TFshgiprEIsPr7NTUSv3IBv1X2bUxOppweFqUlddAzBbZb49FyfRc9Vb8oRKN5AxacDUQMRFI++CKmnXzd4LT7QL2KGARhWgcQqxrLIT4oPXywicus2gg+8m4UuplLITU+jkkrqrwf9tVDnfboVH2F1A/FPb9HYTgdCxaeDqYwcQ2n8DDSfHguCx+JT3cdo0DgFIqdUCwW5Ugmx2zc9Ex3V50N5aAi56WkowaBuNMWuCeLDSjLin95E6N6SfhCl46Di0+FovIDioadRGdCXoGmO+GzZWVYC82ge0euXwUpS9RinKKEQ8pNTKI2NQfX5tr2nZolP+O4DxK7NeBoMp3gPFZ8uQY4PIH/0RShBvT9xs8THvNjZUhGBB7chLN4H40CEigfGURwbg5hM6gbzfTVRfPzpdcQ+vQlfhg6xugEqPl1GefQYihOnofK+poqPjpHhWrwP3+NFCI93H8LIsR7kJw+jMjQIxRgqmuLSTPFhi0XEPruFwKKzqSWU9kDFpwvReAHFidMoH5jW7zdZfDT9UofGAL61VXC5TbCSCI0BVN4HuScOsScGlfdtDQuNxzVTfBhZRvSzmwjeb87MeUpzoeLTxaiBCPLHLkDsHWiZ+MBoGMjUCIx+q4tCK8QHkozw3XsI3XU2JKR0BlR89gBS7wCKB09DivfvafGBJCM0M0dFZ49AxWcPIfUOIH/8ApRAeE+JDyPLCM/cQ/DuPSo6ewgqPnuQytAkilOnoQRCVZv1ou4G8WEkGeGZOYRmqOjsRaj47GEqw5MojU1DjsS7Snx0T2eWis4eh4rPPkDqHUBp8hSkRH9Hiw9XLCFy6zYCS8tUdPYBVHz2EVLvACrDB1EZPthR4iOk1xCZnYX/EV0pYj9BxWcfogbDqAwfRGn8KLRqsWJrxYeVJASWlxGenYVv09uFBCndARWffU5l+CDKE0ehRHuAFogPVyoiMjuL4Py8J3PHKN0LFR8KAECJxlEZOQhxZAKab2u5Ya/EJ7Qwj9D8PIR0uvZlKfsYKj6UJ5AGRlAZmYDUP+xKfPzLjxB8tITA8iPq5VCegIoPZVfkRB/kZD/kaA9UwQept6+u+HDZDBhJgrC+Cn4zA2EtTQWHsitUfCgUSltgrQYKhUJpBVR8KBRKW6DiQ6FQ2gIVHwqF0hao+FAolLZAxYdCobQFKj4UCqUtUPGhUChtgYoPhUJpC1R8KBRKW6DiQ6FQ2gIVHwqF0hao+FAolLZAxYdCobSF/x/IorbvdrrJhgAAAABJRU5ErkJggg==";

    var validResponseTypes = ["code"];
    var validDisplays = ["page", "popup", "touch", "wap"];
    var validPrompt = ["none", "login", "consent", "select_account"];
    var defaultThemes = {
        outline: "outline",
        filledOrange: "filled_orange",
        filledBlack: "filled_black",
        custom: "custom",
    };
    var defaultShapes = {
        sharpEdges: "sharp_edges",
        softEdges: "soft_edges",
        roundedEdges: "rounded_edges",
    };
    var buttonTypes = {
        standard: "standard",
        icon: "icon",
    };
    var defaultButtonLabel = "Sign in with e-Signet";

    function styleInject(css, ref) {
      if ( ref === void 0 ) ref = {};
      var insertAt = ref.insertAt;

      if (!css || typeof document === 'undefined') { return; }

      var head = document.head || document.getElementsByTagName('head')[0];
      var style = document.createElement('style');
      style.type = 'text/css';

      if (insertAt === 'top') {
        if (head.firstChild) {
          head.insertBefore(style, head.firstChild);
        } else {
          head.appendChild(style);
        }
      } else {
        head.appendChild(style);
      }

      if (style.styleSheet) {
        style.styleSheet.cssText = css;
      } else {
        style.appendChild(document.createTextNode(css));
      }
    }

    var css_248z = "/* Theme specific css */\n.SignInWithEsignet-module_standardOutline__la5Rh {\n  border: 2px solid #d8d8d8;\n  background: #ffffff 0% 0% no-repeat padding-box;\n  color: black;\n  font: normal normal 600 14px/17px arial;\n}\n\n.SignInWithEsignet-module_filledOrange__0uQsC {\n  border: 2px solid #eb6f2d;\n  background: #eb6f2d 0% 0% no-repeat padding-box;\n  color: white;\n  font: normal normal 600 14px/17px arial;\n}\n\n.SignInWithEsignet-module_filledBlack__fo-0k {\n  border: 2px solid #333333;\n  background: #333333 0% 0% no-repeat padding-box;\n  color: white;\n  font: normal normal 600 14px/17px arial;\n}\n\n/* Common css */\n.SignInWithEsignet-module_sharpRectBox__jYEvo {\n  width: 400px;\n  height: 48px;\n  display: flex;\n  align-items: center;\n  padding-left: 2px;\n  padding-right: 2px;\n}\n\n.SignInWithEsignet-module_softRectBox__hXT5v {\n  width: 400px;\n  height: 48px;\n  display: flex;\n  align-items: center;\n  border-radius: 8px;\n  padding-left: 2px;\n  padding-right: 2px;\n}\n\n.SignInWithEsignet-module_roundedRectBox__Gxr6n {\n  width: 400px;\n  height: 48px;\n  display: flex;\n  align-items: center;\n  border-radius: 46px;\n  padding-left: 3px;\n  padding-right: 3px;\n}\n\n.SignInWithEsignet-module_sharpRectIcon__ux3fm {\n  display: inline-block;\n}\n\n.SignInWithEsignet-module_softRectIcon__3TVEe {\n  display: inline-block;\n  border-radius: 8px;\n}\n\n.SignInWithEsignet-module_roundedRectIcon__dfq2Q {\n  display: inline-block;\n  border-radius: 46px;\n}\n\n.SignInWithEsignet-module_sharpLogoBox__DYo-n {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  width: 44px;\n  height: 44px;\n  background: #ffffff 0% 0% no-repeat padding-box;\n}\n\n.SignInWithEsignet-module_softLogoBox__jj7aZ {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  width: 44px;\n  height: 44px;\n  background: #ffffff 0% 0% no-repeat padding-box;\n  border-radius: 6px;\n}\n\n.SignInWithEsignet-module_roundedLogoBox__KiQM1 {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  width: 38px;\n  height: 38px;\n  background: #ffffff 0% 0% no-repeat padding-box;\n  border-radius: 36px;\n}\n\n.SignInWithEsignet-module_sharpLogo__wyaBH {\n  width: 38px;\n  height: 38px;\n  object-fit: contain;\n}\n\n.SignInWithEsignet-module_softLogo__Gk5mu {\n  width: 38px;\n  height: 38px;\n  object-fit: contain;\n}\n\n.SignInWithEsignet-module_roundedLogo__cwx4t {\n  width: 28px;\n  height: 28px;\n  object-fit: contain;\n}\n\n.SignInWithEsignet-module_textbox__k2CkO {\n  text-align: left;\n  padding-left: 16px;\n  padding-right: 16px;\n  letter-spacing: 0px;\n}\n";
    var styles = {"standardOutline":"SignInWithEsignet-module_standardOutline__la5Rh","filledOrange":"SignInWithEsignet-module_filledOrange__0uQsC","filledBlack":"SignInWithEsignet-module_filledBlack__fo-0k","sharpRectBox":"SignInWithEsignet-module_sharpRectBox__jYEvo","softRectBox":"SignInWithEsignet-module_softRectBox__hXT5v","roundedRectBox":"SignInWithEsignet-module_roundedRectBox__Gxr6n","sharpRectIcon":"SignInWithEsignet-module_sharpRectIcon__ux3fm","softRectIcon":"SignInWithEsignet-module_softRectIcon__3TVEe","roundedRectIcon":"SignInWithEsignet-module_roundedRectIcon__dfq2Q","sharpLogoBox":"SignInWithEsignet-module_sharpLogoBox__DYo-n","softLogoBox":"SignInWithEsignet-module_softLogoBox__jj7aZ","roundedLogoBox":"SignInWithEsignet-module_roundedLogoBox__KiQM1","sharpLogo":"SignInWithEsignet-module_sharpLogo__wyaBH","softLogo":"SignInWithEsignet-module_softLogo__Gk5mu","roundedLogo":"SignInWithEsignet-module_roundedLogo__cwx4t","textbox":"SignInWithEsignet-module_textbox__k2CkO"};
    styleInject(css_248z);

    var defaultResponseType = "code";
    /**
     * Validates oidc configuration for required params and valid values
     * @param oidcConfig oidc configuration prop
     * @returns Error object with error code and error msg.
     */
    function validateInput(oidcConfig) {
        //Required parameters
        if (!oidcConfig ||
            !oidcConfig.authorizeUri ||
            !oidcConfig.redirect_uri ||
            !oidcConfig.client_id ||
            !oidcConfig.scope) {
            return "Required parameter is missing";
        }
        //if the param is not null and has and an invalid value return error msg.
        if (oidcConfig.response_type &&
            !validResponseTypes.includes(oidcConfig.response_type)) {
            return "Invalid Response Type";
        }
        if (oidcConfig.display && !validDisplays.includes(oidcConfig.display)) {
            return "Invalid display value";
        }
        if (oidcConfig.prompt && !validPrompt.includes(oidcConfig.prompt)) {
            return "Invalid prompt value";
        }
        return "";
    }
    /**
     * Builds redirect URL to navigate to id provider's portal.
     * @param oidcConfig
     * @returns URL
     */
    function buildRedirectURL(oidcConfig) {
        var urlToNavigate = oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.authorizeUri;
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.nonce)
            urlToNavigate += "?nonce=" + oidcConfig.nonce;
        //Generating random state if not provided
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.state) {
            urlToNavigate += "&state=" + oidcConfig.state;
        }
        else {
            var randomNum = window.crypto.getRandomValues(new Uint32Array(1));
            var randomState = randomNum[0].toString(36).substring(5);
            urlToNavigate += "&state=" + randomState;
        }
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.client_id)
            urlToNavigate += "&client_id=" + oidcConfig.client_id;
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.redirect_uri)
            urlToNavigate += "&redirect_uri=" + oidcConfig.redirect_uri;
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.scope)
            urlToNavigate += "&scope=" + oidcConfig.scope;
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.response_type) {
            urlToNavigate += "&response_type=" + oidcConfig.response_type;
        }
        else {
            urlToNavigate += "&response_type=" + defaultResponseType;
        }
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.acr_values)
            urlToNavigate += "&acr_values=" + (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.acr_values);
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.claims)
            urlToNavigate += "&claims=" + encodeURI(JSON.stringify(oidcConfig.claims));
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.claims_locales)
            urlToNavigate += "&claims_locales=" + oidcConfig.claims_locales;
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.display)
            urlToNavigate += "&display=" + oidcConfig.display;
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.prompt)
            urlToNavigate += "&state=" + oidcConfig.prompt;
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.max_age)
            urlToNavigate += "&max_age=" + oidcConfig.max_age;
        if (oidcConfig === null || oidcConfig === void 0 ? void 0 : oidcConfig.ui_locales)
            urlToNavigate += "&ui_locales=" + oidcConfig.ui_locales;
        return urlToNavigate;
    }
    /**
     * builds classes based on input shape, theme and button type.
     *
     * if theme is 'custom' then standard classes are applied and these clases
     *  are expected to be added by the button implementer.
     *
     * @param buttonConfig
     * @returns classes
     */
    function buildButtonClasses(buttonConfig) {
        var outerDivClasses = "";
        var logoDivClasses = "";
        var logoImgClasses = "";
        var labelSpanClasses = styles.textbox;
        if (buttonConfig.theme == defaultThemes.custom) {
            return {
                outerDivClasses: (outerDivClasses =
                    buttonConfig.type == buttonTypes.icon
                        ? "sign-in-outer-div-container-icon"
                        : "sign-in-outer-div-container-standard"),
                logoDivClasses: "sign-in-logo-div-container",
                logoImgClasses: "sign-in-logo-img",
                labelSpanClasses: "sign-in-label-span",
            };
        }
        //theme based styling
        switch (buttonConfig.theme) {
            case defaultThemes.outline:
                outerDivClasses = styles.standardOutline;
                break;
            case defaultThemes.filledOrange:
                outerDivClasses = styles.filledOrange;
                break;
            case defaultThemes.filledBlack:
                outerDivClasses = styles.filledBlack;
                break;
            default: //default theme outline
                outerDivClasses = styles.standardOutline;
        }
        //shaped based styling
        switch (buttonConfig.shape) {
            case defaultShapes.sharpEdges:
                //default button type is standard. Setting shape based on button type
                outerDivClasses +=
                    " " +
                        (buttonConfig.type == buttonTypes.icon
                            ? styles.sharpRectIcon
                            : styles.sharpRectBox);
                logoDivClasses = styles.sharpLogoBox;
                logoImgClasses = styles.sharpLogo;
                break;
            case defaultShapes.softEdges:
                outerDivClasses +=
                    " " +
                        (buttonConfig.type == buttonTypes.icon
                            ? styles.softRectIcon
                            : styles.softRectBox);
                logoDivClasses = styles.softLogoBox;
                logoImgClasses = styles.softLogo;
                break;
            case defaultShapes.roundedEdges:
                outerDivClasses +=
                    " " +
                        (buttonConfig.type == buttonTypes.icon
                            ? styles.roundedRectIcon
                            : styles.roundedRectBox);
                logoDivClasses = styles.roundedLogoBox;
                logoImgClasses = styles.roundedLogo;
                break;
            default: //default shaped SharpEdges
                outerDivClasses +=
                    " " +
                        (buttonConfig.type == buttonTypes.icon
                            ? styles.sharpRectIcon
                            : styles.sharpRectBox);
                logoDivClasses = styles.sharpLogoBox;
                logoImgClasses = styles.sharpLogo;
        }
        return {
            outerDivClasses: outerDivClasses,
            logoDivClasses: logoDivClasses,
            logoImgClasses: logoImgClasses,
            labelSpanClasses: labelSpanClasses,
        };
    }
    /**
     * builds style for the outer div by updating baseStyle by adding/overriding
     *  button config styling parameters.
     * @param baseStyle
     * @param buttonConfig
     * @returns style
     */
    function buildButtonStyles(baseStyle, buttonConfig) {
        if (buttonConfig === null || buttonConfig === void 0 ? void 0 : buttonConfig.width)
            baseStyle["width"] = buttonConfig.width;
        if (buttonConfig === null || buttonConfig === void 0 ? void 0 : buttonConfig.background)
            baseStyle["background"] = buttonConfig.background;
        if (buttonConfig === null || buttonConfig === void 0 ? void 0 : buttonConfig.textColor)
            baseStyle["color"] = buttonConfig.textColor;
        if (buttonConfig === null || buttonConfig === void 0 ? void 0 : buttonConfig.borderWidth)
            baseStyle["border-width"] = buttonConfig.borderWidth;
        if (buttonConfig === null || buttonConfig === void 0 ? void 0 : buttonConfig.borderColor)
            baseStyle["border-color"] = buttonConfig.borderColor;
        if (buttonConfig === null || buttonConfig === void 0 ? void 0 : buttonConfig.font)
            baseStyle["font"] = buttonConfig.font;
        if (buttonConfig === null || buttonConfig === void 0 ? void 0 : buttonConfig.fontFamily) {
            baseStyle["font-family"] = buttonConfig.fontFamily;
        }
        else {
            //default font-family
            baseStyle["font-family"] =
                "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen','Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',sans-serif";
        }
        return baseStyle;
    }
    /**
     * builds style based on button type and custom style.
     *
     * if theme is 'custom' then standard classes are applied and these clases
     *  are expected to be added by the button implementer.
     * @param baseStyle
     * @param buttonConfig
     * @returns
     */
    function buildButtonCustomStyles(baseStyle, buttonConfig) {
        if (!buttonConfig.customStyle) {
            return {};
        }
        var outerDiv = buttonConfig.type == buttonTypes.icon
            ? buttonConfig.customStyle.outerDivStyleIcon
            : buttonConfig.customStyle.outerDivStyleStandard;
        Object.assign(baseStyle, outerDiv);
        return {
            outerDivStyle: buildButtonStyles(baseStyle, buttonConfig),
            logoDivStyle: buttonConfig.customStyle.logoDivStyle,
            logoImgStyle: buttonConfig.customStyle.logoImgStyle,
            labelSpanStyle: buttonConfig.customStyle.labelSpanStyle,
        };
    }
    /**
     * style attrs applied on the element
     * @param element
     * @param attrs
     */
    var setStyleAttribute = function (element, attrs) {
        if (attrs !== undefined) {
            Object.keys(attrs).forEach(function (key) {
                element.style.setProperty(key, attrs[key]);
            });
        }
    };
    /**
     *
     * Builds button while adding styles and classes on individual element
     *
     * In case of buttonClasses, the button should render like this.
     * <span> --conditional
     *   {errorObj + ". Please report to site admin"}
     * </span>
     * <a href={urlToNavigate}>
     *   <div className={buttonClasses.outerDivClasses} style={buttonStyle}>
     *     <div className={buttonClasses.logoDivClasses}>
     *       <img className={buttonClasses.logoImgClasses} src={logoPath} />
     *     </div>
     *      <span className={buttonClasses.labelSpanClasses} >{buttonLabel}</span> --conditional
     *   </div>
     * </a>
     * @param buttonLabel
     * @param urlToNavigate
     * @param buttonCustomStyle
     * @param buttonClasses
     * @param buttonStyle
     * @param logoPath
     * @param errorMsg
     * @param type
     * @returns
     */
    var createButton = function (buttonLabel, urlToNavigate, buttonCustomStyle, buttonClasses, buttonStyle, logoPath, errorMsg, type) {
        var _a, _b, _c, _d;
        //Button
        var anchor = document.createElement("a");
        anchor.href = urlToNavigate;
        anchor.style.textDecoration = "none";
        var outerDiv = document.createElement("div");
        var logoDiv = document.createElement("div");
        var logoImg = document.createElement("img");
        logoImg.src = logoPath;
        var labelSpan = document.createElement("span");
        labelSpan.innerHTML = buttonLabel;
        if (buttonCustomStyle) {
            //apply custom style
            if (buttonCustomStyle.outerDivStyle)
                anchor.style.width = buttonCustomStyle.outerDivStyle["width"];
            setStyleAttribute(outerDiv, buttonCustomStyle.outerDivStyle);
            setStyleAttribute(logoDiv, buttonCustomStyle.logoDivStyle);
            setStyleAttribute(logoImg, buttonCustomStyle.logoImgStyle);
            setStyleAttribute(labelSpan, buttonCustomStyle.labelSpanStyle);
        }
        else if (buttonClasses) {
            //or apply classes
            if (buttonStyle)
                anchor.style.width = buttonStyle["width"];
            setStyleAttribute(outerDiv, buttonStyle);
            (_a = outerDiv.classList).add.apply(_a, buttonClasses.outerDivClasses.split(" "));
            (_b = logoDiv.classList).add.apply(_b, buttonClasses.logoDivClasses.split(" "));
            (_c = logoImg.classList).add.apply(_c, buttonClasses.logoImgClasses.split(" "));
            (_d = labelSpan.classList).add.apply(_d, buttonClasses.labelSpanClasses.split(" "));
        }
        logoDiv.appendChild(logoImg);
        outerDiv.appendChild(logoDiv);
        //Do not add label span for icon button
        if (type != buttonTypes.icon) {
            outerDiv.appendChild(labelSpan);
        }
        if (errorMsg) {
            //adding error span
            var errorSpan = document.createElement("span");
            errorSpan.style.color = "red";
            errorSpan.style.color = "14px";
            errorSpan.innerHTML = errorMsg + ". Please report to site admin";
            anchor.appendChild(errorSpan);
        }
        anchor.appendChild(outerDiv);
        return anchor;
    };
    var SignInWithEsignet = function (_a) {
        var _b, _c;
        var props = __rest(_a, []);
        var oidcConfig = props.oidcConfig, buttonConfig = props.buttonConfig, signInElement = props.signInElement, style = props.style;
        if (signInElement == null) {
            return signInElement;
        }
        //validate input
        var errorMsg = validateInput(oidcConfig);
        var urlToNavigate = "#";
        if (!errorMsg) {
            urlToNavigate = buildRedirectURL(oidcConfig);
        }
        if (!buttonConfig) {
            //default values
            buttonConfig = {
                type: buttonTypes.standard,
                theme: defaultThemes.outline,
                labelText: defaultButtonLabel,
                shape: defaultShapes.sharpEdges,
            };
        }
        var label = (_b = buttonConfig.labelText) !== null && _b !== void 0 ? _b : defaultButtonLabel;
        var logoPath = (_c = buttonConfig.logoPath) !== null && _c !== void 0 ? _c : img;
        var baseStyle = style || {};
        var buttonCustomStyle = null;
        var buttonClasses = null;
        var buttonStyle = {};
        // customStyle has precedence over buttonClasses
        if (buttonConfig.customStyle) {
            buttonCustomStyle = buildButtonCustomStyles(baseStyle, buttonConfig);
        }
        else {
            buttonClasses = buildButtonClasses(buttonConfig);
            buttonStyle = buildButtonStyles(baseStyle, buttonConfig);
        }
        var button = createButton(label, urlToNavigate, buttonCustomStyle, buttonClasses, buttonStyle, logoPath, errorMsg, buttonConfig.type);
        signInElement.innerHTML = "";
        signInElement.appendChild(button);
        return signInElement;
    };
    var init = function (_a) {
        var props = __rest(_a, []);
        return SignInWithEsignet(props);
    };

    exports.init = init;

    Object.defineProperty(exports, '__esModule', { value: true });

    return exports;

})({});
